# Logistic-Regression-for-Sample-Survey-Data
A leading snacks manufacturer wanted to understand the relationship between overall brand perceptions and the drivers of respondent’s decision on a product to determine the most important factors impacting their brands. So built a logistic regression model on sample survey data.
